=== Email Subscription Popup ===
Contributors:nik00726
Tags:wordpress email subscription,Responsive newsletter signup,wordpress newsletter popup,newsletter widget,wordpress ,wordpress email subscription plugin popup,newsletter modal popup,wordpress email subscriber,wordpress,wordpress newsletter email
Donate link: http://www.i13websolution.com/donate_for_mass_email.php
Requires at least:3.0
Tested up to:4.7
Version:1.2.2
Stable tag:1.2.2
License:GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html

== Description ==


Wp Email Subscription is plugin that can be use as newsletter subscription.This is very easy to use plugin.Just set how many times newsletter modal appear when user enter to site.admin can also use this plugin as widget.Admin can also set link for newsletter signup.When click on link the modal popup of newsletter signup will appear.This plugin provide full customization of each and every lables messages and error messages.This plugin can be used for any website localization. 


Additionally admin can view list of subscribers and also can delete selected subscribers.This plugin also can be used for responsive sites.

**Find Email Subscription Pro Plugin at [Wordpress Newsletter Subscription](http://www.i13websolution.com/wordpress-pro-plugins/wordpress-newsletter-subscription-pro-plugin.html)**

**[Live Demo WordPress Newsletter Subscription Pro](http://blog.i13websolution.com/live-preview-wp-newsletter-subscription-plugin/)**

**Video  [WordPress Newsletter Subscription](https://www.youtube.com/watch?v=nqrDS58RE9Q)**

https://www.youtube.com/watch?v=nqrDS58RE9Q

In Pro Version admin Can have open to choose from three diffrent types of designs.In Pro Version Admin Can Change Newsletter box's backgroud color,Border Color,Border Size,Modal Border Color,Title Color,Title Font Size,Sub Title Font Color,Sub Title Font Size,Modal textbox colors,Buttons color etc.Admin Can also have optopns in pro version for auto activate subscriber or via activation email.Admin Can also have option to receive notification when someone su
bscriber to site.


In pro version admin can create newsletter templates.Admin can send mass email or send mass email to selected subscribers.Admin can select newsletter template 
while sending email.In pro version user can be unsubscribe from newsletter email.Admin can see how have unsubscribed from newsletter.Admin can also export subscribers
and admin can also import subscribers.Admin can mass delete subscribers.


**Please rate this plugin if you find it useful**

=Features=

1. Newsletter subscription

2. Responsive design

3. View list of subscribers

4. Delete subscribers

5. Newsletter widget available


**=Pro Version Features(Add On)=**

1. Three Different Types Newsletter POPUPS Designs (See In Screenshots).

2. You Can Change Newsletter box's backgroud color,Border Color,Border Size,Modal Border Color,Title Color,Title Font Size,Sub Title Font Color,Sub Title Font Size,

   Modal textbox colors,Buttons color etc.
   
3. Show Hide Name Feild In Modal Popup and In Newsletter Widget

4. Mass email to subscribers.

5. Social Media Links.

6. Email Notification to admin when someone subscribe.

7. Option to activate Subscriber via activation link or automatic subscribe

8. Import subscribers.

9. Export subscribers.

10. Mass delete subscribers.

11. Newsletter email templates.

12. unsubscribe from newsletter.

13. Username,email,unsubscribe link place holders while sending emails.

14. Search subscribers.

15. View unsubscribers list and take action of resubscribe or delete it.

16. Delay Newsletter Popup.

17. No advertisements.


[Get Support](http://www.i13websolution.com/contacts) 


== Installation ==


This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. upload wp-email-subscription folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use this plugin

### Usage ###

1.Use of wp email subscription plugin is easy after activating plugin go to menu Email Subscription

2.Edit messages and lables as per your localization.

3.Edit cookie settings.

4.you can also use widget if your theme support widget.


== Screenshots ==

1. Newsletter Modal popup settings

2. Preview of modal popup. 

3. Responsive design view.

4. Widget preview.

5. Pro Version Popup Style 1

6. Pro Version Popup Style 2

7.  Pro Version Popup Style 3

8. Pro version features like mass email,import/export,delete subscribers

9. List of unsubscribers

10. Manage newsletter templates

11. Mass email preview

12. Activate subscriber via activation link or automatic activate

13. Notify admin when someone subscribe to newsletter


== License ==

This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.

== Changelog ==

= 1.2.2 =

* fix to work with other fancybox scripts

= 1.2.1 =

* fix class constructor notice when debug mode is on


= 1.2 =

* Security updates 


= 1.0 =

* Stable 1.0 first release


== Upgrade Notice ==

= 1.2.2 =

* fix to work with other fancybox scripts

= 1.2.1 =

* fix class constructor notice when debug mode is on
* Pro version please contact us insted updating from here.


= 1.2 =

* Security updates.
* Pro version please contact us insted updating from here.


= 1.0 =

* Stable 1.0 first release

 
== Frequently Asked Questions ==

1.How to use ?

For frontend side use please use widget feature.more more info use readme installation and usage notes.
